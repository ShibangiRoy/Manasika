#!/usr/bin/env python3
"""Manasika's small, dependency-free local prototype server."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import sqlite3
import time
from datetime import datetime, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("MANASIKA_DB", ROOT / "data" / "manasika.sqlite3"))
PORT = int(os.environ.get("PORT", "8000"))
BIND_ADDRESS = os.environ.get("BIND_ADDRESS", "127.0.0.1")
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "0") == "1"
SESSION_SECONDS = 60 * 60 * 24 * 30
CATEGORIES = {"reflection", "sound", "art", "poetry", "narration"}


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def db() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def initialize() -> None:
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY, name TEXT NOT NULL, handle TEXT NOT NULL UNIQUE COLLATE NOCASE,
          email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL,
          bio TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sessions (
          token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          expires_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS follows (
          follower_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          following_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          created_at TEXT NOT NULL, PRIMARY KEY(follower_id, following_id),
          CHECK(follower_id <> following_id)
        );
        CREATE TABLE IF NOT EXISTS posts (
          id INTEGER PRIMARY KEY, author_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          category TEXT NOT NULL, body TEXT NOT NULL, media_url TEXT NOT NULL DEFAULT '',
          tags TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, reach_count INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS post_likes (
          post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
          user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          created_at TEXT NOT NULL, PRIMARY KEY(post_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS post_reaches (
          post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
          visitor_key TEXT NOT NULL, created_at TEXT NOT NULL,
          PRIMARY KEY(post_id, visitor_key)
        );
        CREATE INDEX IF NOT EXISTS posts_created_idx ON posts(created_at DESC);
        CREATE INDEX IF NOT EXISTS posts_category_idx ON posts(category, created_at DESC);
        CREATE INDEX IF NOT EXISTS follows_follower_idx ON follows(follower_id);
        """)
        post_columns = {row[1] for row in conn.execute("PRAGMA table_info(posts)")}
        if "tags" not in post_columns:
            conn.execute("ALTER TABLE posts ADD COLUMN tags TEXT NOT NULL DEFAULT ''")
        seed_demo(conn)
        demo_tags = {"anayamehta": "softthings,healingwords", "julesrivera": "rainyday,slowmusic", "mirasol": "smallgardens,stillness", "theowren": "slowmornings,smallbrave", "niarivers": "voicenotes,smallbrave"}
        for handle, tags in demo_tags.items():
            conn.execute("UPDATE posts SET tags=? WHERE tags='' AND author_id=(SELECT id FROM users WHERE handle=?)", (tags, handle))


def seed_demo(conn: sqlite3.Connection) -> None:
    if conn.execute("SELECT 1 FROM users LIMIT 1").fetchone():
        return
    demos = [
        ("Anaya Mehta", "anayamehta", "anaya@example.local", "Poet & night-walker. Collecting small reasons to stay soft."),
        ("Jules Rivera", "julesrivera", "jules@example.local", "Sound artist making quiet places to land."),
        ("Mira Sol", "mirasol", "mira@example.local", "Illustrator of gentle worlds and ordinary magic."),
        ("Theo Wren", "theowren", "theo@example.local", "Ambient music for slow mornings."),
        ("Nia Rivers", "niarivers", "nia@example.local", "Poetry, voice notes, and things I almost didn't say."),
    ]
    ids: dict[str, int] = {}
    for name, handle, email, bio in demos:
        # Demo accounts are discoverable, but use the normal registration flow to sign in.
        cur = conn.execute("INSERT INTO users(name,handle,email,password_hash,bio,created_at) VALUES(?,?,?,?,?,?)",
                           (name, handle, email, "demo-account-no-login", bio, now()))
        ids[handle] = cur.lastrowid
    examples = [
        ("anayamehta", "poetry", "Maybe healing is not becoming who you were before. Maybe it’s meeting who you are now, with softer eyes.", "softthings,healingwords", 128),
        ("julesrivera", "sound", "I made a tiny sound for days that ask too much of you. Rain on the studio skylight, a little piano, and nowhere you need to be.", "rainyday,slowmusic", 96),
        ("mirasol", "art", "A little window garden for anyone who needs somewhere green to rest their eyes today.", "smallgardens,stillness", 72),
        ("theowren", "reflection", "Today I am practicing the difference between being still and being stuck.", "slowmornings,smallbrave", 43),
        ("niarivers", "narration", "A voice note to my future self: you made it through every day you thought would be the last of your courage.", "voicenotes,smallbrave", 81),
    ]
    for handle, category, body, tags, reach in examples:
        conn.execute("INSERT INTO posts(author_id,category,body,tags,created_at,reach_count) VALUES(?,?,?,?,?,?)",
                     (ids[handle], category, body, tags, now(), reach))


def password_hash(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return base64.urlsafe_b64encode(salt).decode().rstrip("=") + "$" + base64.urlsafe_b64encode(digest).decode().rstrip("=")


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_text, digest_text = stored.split("$", 1)
        salt = base64.urlsafe_b64decode(salt_text + "=" * (-len(salt_text) % 4))
        expected = base64.urlsafe_b64decode(digest_text + "=" * (-len(digest_text) % 4))
        candidate = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
        return secrets.compare_digest(candidate, expected)
    except (ValueError, TypeError):
        return False


class Handler(SimpleHTTPRequestHandler):
    server_version = "ManasikaLocal/1.0"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def translate_path(self, path):
        requested = unquote(urlparse(path).path).lstrip("/")
        if requested in ("", "index.html"):
            return str(ROOT / "index.html")
        pieces = requested.split("/")
        if len(pieces) == 2 and pieces[0] == "assets" and pieces[1].lower().endswith(".mp4") and not pieces[1].startswith("."):
            candidate = ROOT / "assets" / pieces[1]
            if candidate.is_file():
                return str(candidate)
        return str(ROOT / "__not_found__")

    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def send_json(self, data, status=HTTPStatus.OK, headers=None):
        payload = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        if headers:
            for key, value in headers.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(payload)

    def body(self):
        try:
            length = min(int(self.headers.get("Content-Length", "0")), 1_000_000)
            return json.loads(self.rfile.read(length) or b"{}")
        except (ValueError, json.JSONDecodeError):
            raise ValueError("Send a valid JSON request body.")

    def get_user(self):
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
            token = cookie.get("manasika_session").value if cookie.get("manasika_session") else ""
        except Exception:
            token = ""
        if not token:
            return None
        with db() as conn:
            row = conn.execute("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>?",
                               (token, int(time.time()))).fetchone()
            return dict(row) if row else None

    def require_user(self):
        user = self.get_user()
        if not user:
            self.send_json({"error": "Sign in to do that."}, HTTPStatus.UNAUTHORIZED)
            return None
        return user

    def session_cookie(self, token, max_age=SESSION_SECONDS):
        secure = "; Secure" if COOKIE_SECURE else ""
        return f"manasika_session={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={max_age}{secure}"

    def do_GET(self):
        parsed = urlparse(self.path)
        if not parsed.path.startswith("/api/"):
            if parsed.path == "/":
                self.path = "/index.html"
            return super().do_GET()
        q = parse_qs(parsed.query)
        try:
            if parsed.path == "/api/health":
                with db() as conn:
                    conn.execute("SELECT 1")
                return self.send_json({"ok": True, "database": "sqlite", "time": now()})
            if parsed.path == "/api/me":
                user = self.get_user()
                return self.send_json({"user": self.public_user(user) if user else None})
            if parsed.path in ("/api/feed", "/api/spaces"):
                user = self.get_user()
                category = q.get("category", [""])[0].lower()
                search = q.get("q", [""])[0].strip()[:100]
                if category and category not in CATEGORIES:
                    return self.send_json({"error": "Unknown space."}, HTTPStatus.BAD_REQUEST)
                clauses, args = [], []
                if category:
                    clauses.append("p.category=?"); args.append(category)
                if search:
                    clauses.append("(p.body LIKE ? OR p.tags LIKE ? OR u.name LIKE ? OR u.handle LIKE ? OR u.bio LIKE ?)")
                    term = search.lstrip("#")
                    args.extend([f"%{term}%"] * 5)
                where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
                uid = user["id"] if user else 0
                sql = f"""SELECT p.id,p.author_id,p.category,p.body,p.media_url,p.created_at,p.reach_count,
                         u.name,u.handle,u.bio,
                         (SELECT COUNT(*) FROM post_likes l WHERE l.post_id=p.id) AS likes,
                         EXISTS(SELECT 1 FROM post_likes l WHERE l.post_id=p.id AND l.user_id=?) AS liked,
                         EXISTS(SELECT 1 FROM follows f WHERE f.follower_id=? AND f.following_id=p.author_id) AS followed,
                         (SELECT COUNT(*) FROM follows f WHERE f.following_id=p.author_id) AS followers
                         FROM posts p JOIN users u ON u.id=p.author_id {where}
                         ORDER BY followed DESC, (p.reach_count + likes*4) DESC, p.created_at DESC LIMIT 100"""
                with db() as conn:
                    rows = conn.execute(sql, [uid, uid, *args]).fetchall()
                return self.send_json({"posts": [dict(row) for row in rows]})
            if parsed.path == "/api/artists":
                user = self.get_user(); uid = user["id"] if user else 0
                search = q.get("q", [""])[0].strip()[:100]
                with db() as conn:
                    rows = conn.execute("""SELECT u.id,u.name,u.handle,u.bio,u.created_at,
                      (SELECT COUNT(*) FROM posts p WHERE p.author_id=u.id) post_count,
                      (SELECT COUNT(*) FROM follows f WHERE f.following_id=u.id) followers,
                      EXISTS(SELECT 1 FROM follows f WHERE f.follower_id=? AND f.following_id=u.id) followed
                      FROM users u WHERE (?='' OR u.name LIKE ? OR u.handle LIKE ? OR u.bio LIKE ?)
                      ORDER BY followers DESC,u.name COLLATE NOCASE LIMIT 60""",
                      (uid, search, f"%{search}%", f"%{search}%", f"%{search}%")).fetchall()
                return self.send_json({"artists": [dict(row) for row in rows]})
            if parsed.path == "/api/trends":
                counts: dict[str, int] = {}
                with db() as conn:
                    rows = conn.execute("SELECT tags FROM posts WHERE tags<>''").fetchall()
                for row in rows:
                    for tag in row["tags"].split(","):
                        tag = tag.strip().lower().lstrip("#")
                        if tag:
                            counts[tag] = counts.get(tag, 0) + 1
                trends = sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:12]
                return self.send_json({"trends": [{"tag": tag, "posts": count} for tag, count in trends]})
            if parsed.path == "/api/following":
                user = self.get_user()
                if not user:
                    return self.send_json({"artists": []})
                with db() as conn:
                    rows = conn.execute("SELECT u.id,u.name,u.handle,u.bio FROM follows f JOIN users u ON u.id=f.following_id WHERE f.follower_id=? ORDER BY f.created_at DESC", (user["id"],)).fetchall()
                return self.send_json({"artists": [dict(row) for row in rows]})
            if parsed.path == "/api/companion":
                return self.send_json({"name": "Mira", "mode": "local-guide", "tools": ["search_artists", "open_space", "open_composer", "mood_check_in"]})
            return self.send_json({"error": "Not found."}, HTTPStatus.NOT_FOUND)
        except sqlite3.Error as exc:
            print("Database error:", exc)
            return self.send_json({"error": "The local database could not complete that request."}, HTTPStatus.INTERNAL_SERVER_ERROR)

    @staticmethod
    def public_user(user):
        return {"id": user["id"], "name": user["name"], "handle": user["handle"], "bio": user["bio"]}

    def do_POST(self):
        parsed = urlparse(self.path)
        try:
            data = self.body()
        except ValueError as exc:
            return self.send_json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
        try:
            if parsed.path == "/api/register":
                name = str(data.get("name", "")).strip()[:60]
                handle = re.sub(r"[^a-zA-Z0-9_]", "", str(data.get("handle", "")).strip().lstrip("@"))[:24]
                email = str(data.get("email", "")).strip().lower()[:160]
                password = str(data.get("password", ""))
                bio = str(data.get("bio", "")).strip()[:240]
                if len(name) < 2 or len(handle) < 3 or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email) or len(password) < 8:
                    return self.send_json({"error": "Add a name, a 3+ character handle, a valid email, and a password of at least 8 characters."}, HTTPStatus.BAD_REQUEST)
                with db() as conn:
                    cur = conn.execute("INSERT INTO users(name,handle,email,password_hash,bio,created_at) VALUES(?,?,?,?,?,?)",
                                       (name, handle, email, password_hash(password), bio, now()))
                    user_id = cur.lastrowid
                    token = secrets.token_urlsafe(32)
                    conn.execute("INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,?)", (token, user_id, int(time.time()) + SESSION_SECONDS))
                    user = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
                return self.send_json({"user": self.public_user(user)}, HTTPStatus.CREATED, {"Set-Cookie": self.session_cookie(token)})
            if parsed.path == "/api/login":
                login = str(data.get("login", "")).strip()
                password = str(data.get("password", ""))
                with db() as conn:
                    user = conn.execute("SELECT * FROM users WHERE email=? COLLATE NOCASE OR handle=? COLLATE NOCASE", (login, login.lstrip("@"))).fetchone()
                    if not user or not verify_password(password, user["password_hash"]):
                        return self.send_json({"error": "That login didn’t match. Try again or make a new account."}, HTTPStatus.UNAUTHORIZED)
                    token = secrets.token_urlsafe(32)
                    conn.execute("INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,?)", (token, user["id"], int(time.time()) + SESSION_SECONDS))
                return self.send_json({"user": self.public_user(user)}, headers={"Set-Cookie": self.session_cookie(token)})
            if parsed.path == "/api/logout":
                token = self.session_token()
                with db() as conn:
                    if token:
                        conn.execute("DELETE FROM sessions WHERE token=?", (token,))
                return self.send_json({"ok": True}, headers={"Set-Cookie": self.session_cookie("", 0)})
            if parsed.path == "/api/companion":
                message = str(data.get("message", "")).strip()[:500]
                low = message.lower()
                action = {"type": "none"}
                if any(word in low for word in ("write", "post", "share", "create", "poem", "poetry")):
                    action = {"type": "compose"}
                    reply = "I’ve opened a little space for your words. You can keep it private in this browser or share it with the community."
                elif any(word in low for word in ("artist", "find", "discover", "search", "follow")):
                    action = {"type": "view", "view": "artists"}
                    query = re.search(r"(?:find|search for|discover)\s+(.+)", message, re.I)
                    if query:
                        action["query"] = query.group(1).strip(" .?!")[:80]
                    reply = "I’ve opened artist discovery. Tell me a name or a kind of work and we can look together."
                elif any(word in low for word in ("sound", "music", "song", "listen", "garden")):
                    action = {"type": "view", "view": "sound"}
                    reply = "Taking you to the Sound Garden, where independent makers leave small places to land."
                elif any(word in low for word in ("art", "picture", "stillness", "draw")):
                    action = {"type": "view", "view": "art"}
                    reply = "Let’s wander through Art & Stillness for a moment."
                elif any(word in low for word in ("voice", "narrat", "read aloud", "spoken")):
                    action = {"type": "view", "view": "poetry"}
                    reply = "I’ve opened Poetry & Voice. You can share a poem, a reading, or a small spoken thought."
                elif any(word in low for word in ("feel", "mood", "heavy", "anxious", "sad", "happy", "check")):
                    action = {"type": "mood"}
                    reply = "We can pause here. Pick the weather that feels closest, or leave it unanswered. There’s no score and no diagnosis."
                else:
                    reply = "I’m here with you. We could find an artist, open a creative space, make a small post, or take a gentle mood check-in."
                return self.send_json({"reply": reply, "action": action, "mode": "local-guide"})
            user = self.require_user()
            if not user:
                return
            follow_match = re.fullmatch(r"/api/artists/(\d+)/follow", parsed.path)
            if follow_match:
                target = int(follow_match.group(1))
                if target == user["id"]:
                    return self.send_json({"error": "You’re already here with yourself."}, HTTPStatus.BAD_REQUEST)
                with db() as conn:
                    if not conn.execute("SELECT 1 FROM users WHERE id=?", (target,)).fetchone():
                        return self.send_json({"error": "Artist not found."}, HTTPStatus.NOT_FOUND)
                    existing = conn.execute("SELECT 1 FROM follows WHERE follower_id=? AND following_id=?", (user["id"], target)).fetchone()
                    if existing:
                        conn.execute("DELETE FROM follows WHERE follower_id=? AND following_id=?", (user["id"], target)); followed = False
                    else:
                        conn.execute("INSERT INTO follows(follower_id,following_id,created_at) VALUES(?,?,?)", (user["id"], target, now())); followed = True
                return self.send_json({"followed": followed})
            if parsed.path == "/api/posts":
                category = str(data.get("category", "reflection")).lower()
                body = str(data.get("body", "")).strip()[:2000]
                media_url = str(data.get("media_url", "")).strip()[:500]
                tags_raw = data.get("tags", [])
                if isinstance(tags_raw, str):
                    tags_raw = tags_raw.split(",")
                if not isinstance(tags_raw, (list, tuple)):
                    tags_raw = []
                tags = ",".join(dict.fromkeys(re.sub(r"[^a-zA-Z0-9_]", "", str(tag).strip().lstrip("#")).lower()[:32] for tag in tags_raw if str(tag).strip()))[:500]
                if category not in CATEGORIES or len(body) < 3:
                    return self.send_json({"error": "Choose a space and write at least 3 characters."}, HTTPStatus.BAD_REQUEST)
                if media_url and not media_url.startswith(("https://", "http://")):
                    return self.send_json({"error": "Work links need to start with http:// or https://."}, HTTPStatus.BAD_REQUEST)
                with db() as conn:
                    cur = conn.execute("INSERT INTO posts(author_id,category,body,media_url,tags,created_at) VALUES(?,?,?,?,?,?)", (user["id"], category, body, media_url, tags, now()))
                    post_id = cur.lastrowid
                    row = conn.execute("SELECT p.*,u.name,u.handle,0 likes,0 liked,0 followed FROM posts p JOIN users u ON u.id=p.author_id WHERE p.id=?", (post_id,)).fetchone()
                return self.send_json({"post": dict(row)}, HTTPStatus.CREATED)
            like_match = re.fullmatch(r"/api/posts/(\d+)/like", parsed.path)
            if like_match:
                post_id = int(like_match.group(1))
                with db() as conn:
                    if not conn.execute("SELECT 1 FROM posts WHERE id=?", (post_id,)).fetchone():
                        return self.send_json({"error": "Post not found."}, HTTPStatus.NOT_FOUND)
                    current = conn.execute("SELECT 1 FROM post_likes WHERE post_id=? AND user_id=?", (post_id, user["id"])).fetchone()
                    if current:
                        conn.execute("DELETE FROM post_likes WHERE post_id=? AND user_id=?", (post_id, user["id"])); liked = False
                    else:
                        conn.execute("INSERT INTO post_likes(post_id,user_id,created_at) VALUES(?,?,?)", (post_id, user["id"], now())); liked = True
                    count = conn.execute("SELECT COUNT(*) FROM post_likes WHERE post_id=?", (post_id,)).fetchone()[0]
                return self.send_json({"liked": liked, "likes": count})
            reach_match = re.fullmatch(r"/api/posts/(\d+)/reach", parsed.path)
            if reach_match:
                post_id = int(reach_match.group(1))
                visitor = self.session_token() or self.anonymous_token()
                with db() as conn:
                    cur = conn.execute("INSERT OR IGNORE INTO post_reaches(post_id,visitor_key,created_at) VALUES(?,?,?)", (post_id, visitor, now()))
                    if cur.rowcount:
                        conn.execute("UPDATE posts SET reach_count=reach_count+1 WHERE id=?", (post_id,))
                    row = conn.execute("SELECT reach_count FROM posts WHERE id=?", (post_id,)).fetchone()
                return self.send_json({"reach": row[0] if row else 0})
            return self.send_json({"error": "Not found."}, HTTPStatus.NOT_FOUND)
        except sqlite3.IntegrityError as exc:
            message = "That handle or email is already registered." if parsed.path == "/api/register" else str(exc)
            return self.send_json({"error": message}, HTTPStatus.CONFLICT)
        except sqlite3.Error as exc:
            print("Database error:", exc)
            return self.send_json({"error": "The local database could not complete that request."}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def session_token(self):
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
            return cookie.get("manasika_session").value if cookie.get("manasika_session") else ""
        except Exception:
            return ""

    def anonymous_token(self):
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
            token = cookie.get("manasika_visitor").value if cookie.get("manasika_visitor") else ""
        except Exception:
            token = ""
        if not token:
            token = secrets.token_urlsafe(18)
            self._visitor_cookie = f"manasika_visitor={token}; Path=/; SameSite=Lax; Max-Age=31536000"
        return token

    def end_headers(self):
        visitor_cookie = getattr(self, "_visitor_cookie", None)
        if visitor_cookie:
            self.send_header("Set-Cookie", visitor_cookie)
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Allow", "GET, POST, OPTIONS")
        self.end_headers()


if __name__ == "__main__":
    initialize()
    server = ThreadingHTTPServer((BIND_ADDRESS, PORT), Handler)
    print(f"Manasika listening on http://{BIND_ADDRESS}:{PORT} · sqlite: {DB_PATH}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nManasika server stopped.")
        server.server_close()
