# Manasika

An artistic community prototype for independent sound, visual art, poetry, narration, and reflective notes. The visual surface is a pale paper canvas with the supplied summer-dress and boho clips playing as soft background film. The navigation is pinned paper, and the feed is a field of sticky notes.

## Run locally with Docker

1. Install Docker Desktop with Docker Compose enabled.
2. Copy `.env.example` to `.env` if you want to change the local port.
3. From this folder, run `docker compose up --build`.
4. Open [http://127.0.0.1:8000](http://127.0.0.1:8000).

The compose port is bound to loopback, so this default is accessible only from this computer. The database is kept in the named `manasika_data` volume and survives container rebuilds.

## Run without Docker

Python 3.10 or newer is enough; there are no third-party Python packages.

```powershell
$env:PORT = "8000"
$env:MANASIKA_DB = "data/manasika.sqlite3"
python server.py
```

## What works in this prototype

- Account registration and sign-in using a password hash and an HTTP-only local session cookie.
- Artist discovery by name, handle, bio, post text, or hashtag.
- Follow and unfollow other registered profiles.
- Create notes in the common room, Sound Garden, Art & Stillness, Poetry, or Narration. Posts can include comma or space separated hashtags and an optional link to a hosted work.
- Like posts and see hashtag trends.
- Count post reach once per registered session or anonymous browser. Feed ordering uses followed creators first, then reach and likes as a lightweight discovery signal.
- Mira voice guide uses browser speech recognition and speech synthesis when available. Its local companion endpoint routes a small set of clear intents to app actions: open a space, find an artist, compose a post, or open mood check-in.
- The app checks its SQLite-backed health endpoint and reports when the server is offline.

The home feed contains sample maker profiles and notes on first launch. Sample accounts are public for browsing and are not sign-in accounts. Make a new account to post, like, or follow. The first-run sample database is created automatically; it is not reseeded after you clear the database volume.

## API map

- `GET /api/health`, `/api/me`, `/api/feed`, `/api/artists`, `/api/following`, `/api/trends`
- `POST /api/register`, `/api/login`, `/api/logout`, `/api/posts`, `/api/posts/{id}/like`, `/api/posts/{id}/reach`, `/api/artists/{id}/follow`, `/api/companion`

SQLite creates its schema and applies the `tags` column migration on startup. The app uses only Python's standard library. No external AI key or third-party API is configured: Mira is a small local intent-and-action guide, not a generative clinical or mental-health service.

## Prototype limits

Creator media is represented by an optional hosted URL; this prototype does not upload audio or artwork files. Accounts are local to this one SQLite database, with no email verification, password recovery, moderation queue, or multi-server database. For an internet deployment, place it behind HTTPS, enable secure cookies, configure a domain and DNS at the chosen host, and add production-grade account recovery, moderation, backups, and media storage.
