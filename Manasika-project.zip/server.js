const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const appRoot = __dirname;
try {
  for (const line of fs.readFileSync(path.join(appRoot, '.env'), 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (match && process.env[match[1]] === undefined) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '');
  }
} catch { /* .env is optional; environment variables take precedence. */ }
const root = process.env.MANISIKA_DIST_DIR || path.join(appRoot, 'shivUIdes', 'MANASIKA Wellness Platform (UI)', 'dist');
const port = Number(process.env.PORT || 4173);
const host = process.env.HOST || '127.0.0.1';
const ollamaUrl = process.env.MANISIKA_OLLAMA_URL || '';
const ollamaModel = process.env.MANISIKA_OLLAMA_MODEL || '';
const types = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.txt': 'text/plain; charset=utf-8',
};

http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/api/status') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ localModelConfigured: Boolean(ollamaUrl && ollamaModel), model: ollamaModel || null }));
    return;
  }
  if (req.method === 'POST' && req.url === '/api/chat') {
    if (!ollamaUrl || !ollamaModel) {
      res.writeHead(503, { 'Content-Type': 'application/json' }).end(JSON.stringify({ error: 'Local model is not configured.' }));
      return;
    }
    let raw = '';
    req.on('data', chunk => { raw += chunk; if (raw.length > 24000) req.destroy(); });
    req.on('end', async () => {
      try {
        const payload = JSON.parse(raw || '{}');
        const messages = Array.isArray(payload.messages) ? payload.messages.slice(-8).map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '').slice(0, 1500) })) : [];
        messages.unshift({ role: 'system', content: 'You are a brief, kind wellness companion, not a therapist. Do not diagnose or make promises. Offer one gentle, practical next step. If the user may harm themselves or someone else, encourage immediate local emergency help and a trusted person. Keep the reply under 90 words.' });
        const response = await fetch(ollamaUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model: ollamaModel, messages, stream: false }) });
        const result = await response.json();
        const reply = result.message?.content || result.choices?.[0]?.message?.content;
        if (!response.ok || !reply) throw new Error('Model response unavailable');
        res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify({ reply }));
      } catch {
        res.writeHead(502, { 'Content-Type': 'application/json' }).end(JSON.stringify({ error: 'Local model could not respond.' }));
      }
    });
    return;
  }
  let pathname;
  try {
    pathname = decodeURIComponent(new URL(req.url, `http://${req.headers.host}`).pathname);
  } catch {
    res.writeHead(400).end('Bad request');
    return;
  }
  const relativePath = pathname === '/' ? 'index.html' : pathname.slice(1);
  const filePath = path.resolve(root, relativePath);
  if (!filePath.startsWith(`${root}${path.sep}`)) {
    res.writeHead(403).end('Forbidden');
    return;
  }
  fs.readFile(filePath, (error, data) => {
    if (error && error.code === 'ENOENT' && !path.extname(filePath)) {
      fs.readFile(path.join(root, 'index.html'), (indexError, indexData) => {
        if (indexError) {
          res.writeHead(404).end('Figma UI has not been built. Run npm install and npm run build in the shivUIdes project.');
          return;
        }
        res.writeHead(200, { 'Content-Type': types['.html'] });
        res.end(indexData);
      });
      return;
    }
    if (error) {
      res.writeHead(error.code === 'ENOENT' ? 404 : 500).end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': types[path.extname(filePath)] || 'application/octet-stream' });
    res.end(data);
  });
}).listen(port, host, () => {
  console.log(`Manisika is running at http://${host}:${port}`);
});
